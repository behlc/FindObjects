using UnityEditor.Build;
using UnityEngine;

public class ObjectManager : MonoBehaviour
{
    //private Play playScript;
    //private GameObject play;
    private string matchTag;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        matchTag = GameObject.Find("Play").GetComponent<Play>().findTag;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnMouseDown()
    {
        if (gameObject.tag == matchTag)
        {
            Destroy(gameObject);
        }
        
    }
}
