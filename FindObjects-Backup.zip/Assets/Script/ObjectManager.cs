using UnityEditor.Build;
using UnityEngine;

public class ObjectManager : MonoBehaviour
{
    private Play playScript;
    //private int objCount = 0;

    //private GameObject play;
    private string matchTag;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playScript = GameObject.Find("Play").GetComponent<Play>();
        matchTag = playScript.findTag;
    }

    // Update is called once per frame
    void Update()
    {
        //GameObject[] objects = GameObject.FindGameObjectsWithTag(matchTag);
        //objCount = objects.Length;
        
        //if(objCount == 0)
        //{
        //    Debug.Log("Completed");
        //}
    }

    private void OnMouseDown()
    {
        if (gameObject.tag == matchTag)
        {
            AudioController.Instance.PlaySound(AudioController.Instance.correctAnswer);

            Destroy(gameObject);
        }
        else
        {
            AudioController.Instance.PlaySound(AudioController.Instance.wrongAnswer);
        }

    }
}
