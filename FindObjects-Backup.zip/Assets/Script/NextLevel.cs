using UnityEngine;

public class NextLevel : MonoBehaviour
{
    public void LoadNextScene()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("Level0001");
        Time.timeScale = 1;
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
