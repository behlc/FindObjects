using UnityEngine;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine.Rendering;

public class Play : MonoBehaviour
{
    //[SerializeField] private int objectNumber;

    [SerializeField] private List<int> objectNumber;
    [SerializeField] private List<bool> quadrantUsage;

    [SerializeField] private List<float> q_minX;
    [SerializeField] private List<float> q_maxX;

    [SerializeField] private List<float> q_minY;
    [SerializeField] private List<float> q_maxY;

    [SerializeField] private float wordX;
    [SerializeField] private float wordY;

    private Vector2 spawnPoint;
    private Vector2 wordPoint;

    public List<GameObject> findObjects;

    public string findTag;
    private int objCount = 0;

    public GameObject winUI;

    [SerializeField] GameObject findObjectsName;

    void Awake()
    {
        winUI.SetActive(false);
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        for (int j = 0; j < objectNumber.Count; j++)
        {
            if(quadrantUsage[j] == true)
            {
                objectNumber[j] = Random.Range(2,10);

                for (int i = 0; i < objectNumber[j]; i++)
                {
                    spawnPoint.x = Random.Range(q_minX[j], q_maxX[j]);

                    spawnPoint.y = Random.Range(q_minY[j], q_maxY[j]);

                    Instantiate(findObjects[j], spawnPoint, transform.rotation);

                }
            }
        }
        
        wordPoint.x = wordX;
        wordPoint.y = wordY;

        Instantiate(findObjectsName, wordPoint, transform.rotation);
    }

    private void Update()
    {
        GameObject[] objects = GameObject.FindGameObjectsWithTag(findTag);
        objCount = objects.Length;
        
        if(objCount == 0)
        {
            //Debug.Log("Completed");
            Time.timeScale = 0f;
            winUI.SetActive(true);
        }
    }

}