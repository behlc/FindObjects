using UnityEngine;
using System.Collections.Generic;
using System.Runtime.CompilerServices;


public class Play : MonoBehaviour
{
    //[SerializeField] private int objectNumber;

    [SerializeField] private List<int> objectNumber;

    [SerializeField] private List<float> q_minX;
    [SerializeField] private List<float> q_maxX;

    [SerializeField] private List<float> q_minY;
    [SerializeField] private List<float> q_maxY;

    //[SerializeField] private float minX ;
    //[SerializeField] private float maxX ;

    //[SerializeField] private float minY ;
    //[SerializeField] private float maxY ;

    private Vector2 spawnPoint;
        
    public List<GameObject> findObjects;
    public List<GameObject> findObjectsName;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        for (int j = 0; j < objectNumber.Count; j++)
        {

            for (int i = 0; i < objectNumber[j]; i++)
            {
                spawnPoint.x = Random.Range(q_minX[j], q_maxX[j]);

                spawnPoint.y = Random.Range(q_minY[j], q_maxY[j]);

                Instantiate(findObjects[j], spawnPoint, transform.rotation);

            }
        }


        //for (int i = 0; i < objectNumber[0]; i++)
        //{
        //    spawnPoint.x = Random.Range(q_minX[0], q_maxX[0]);

        //    spawnPoint.y = Random.Range(q_minY[0], q_maxY[0]);

        //    Instantiate(findObjects[0], spawnPoint, transform.rotation);
        //}
    }

}